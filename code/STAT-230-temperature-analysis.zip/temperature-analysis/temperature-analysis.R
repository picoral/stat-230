# load libraries
library(tidyverse)

# read data in
temperatures <- read_csv("data/average-monthly-surface-temperature.csv")

# inspect the data
temperatures |>
  glimpse()

temperatures |>
  summary()

# distribution -- histograms
temperatures |>
  ggplot(aes(x = daily_average)) +
  geom_histogram()


temperatures |>
  ggplot(aes(x = monthly_average)) +
  geom_histogram()

## scatter plot
temperatures |>
  ggplot(aes(x = year, y = daily_average)) +
  geom_point()

# summarize the data
by_year <- temperatures |>
  group_by(year) |>
  summarize(mean = mean(daily_average))

# visualize summarized data
by_year |>
  ggplot(aes(x = year, y = mean)) +
  geom_point() 

# visualize filtered data
library(ggthemes)

countries <- c("USA", "BRA", "CHL", "ECU", "PHL", "BFA")

temperatures <- temperatures |>
  mutate(f_temp = daily_average * 9/5 + 32,
         f_yearly = monthly_average * 9/5 + 32)

temperatures |>
  filter(country_code %in% countries) |>
  ggplot(aes(x = year, y = f_yearly, color = country_code)) +
  geom_point() +
  geom_line() +
  scale_color_colorblind() +
  theme_fivethirtyeight() +
  labs(title = "Average temperature 1940-2024")

# How does temperature change across months in the US?
temperatures <- temperatures |>
  mutate(month = month(day))


countries <- c("USA", "CHL", "BFA", "BRA")

temperatures |>
  filter(country_code %in% countries) |>
  ggplot(aes(x = month, y = f_temp, color = country_code)) +
  geom_point() +
  scale_x_continuous(breaks = c(1:12)) +
  facet_wrap(~country_code, scales = "free")
























# load libraries
library(tidyverse)

# load data
county <- read_csv("data/county.csv")

# calculate mean of unemployment
county |>
  summarize(mean(unemployment_rate, na.rm = TRUE))

# scatterplot
county |>
  ggplot(aes(y = unemployment_rate, x = per_capita_income)) +
  geom_point()

# histogram
county |>
  ggplot(aes(x = unemployment_rate)) +
  geom_histogram(bins = 100)


# calculate mean and median
county |>
  summarize(mean = mean(unemployment_rate, na.rm = TRUE),
            median = median(unemployment_rate, na.rm = TRUE))
# calculate mode
county |>
  count(unemployment_rate, sort = TRUE)

# calculate min, max, and range (max-min)
county |>
  summarize(min = min(unemployment_rate, na.rm = TRUE),
            max = max(unemployment_rate, na.rm = TRUE)) |>
  mutate(range = max - min)

# calculate standard deviation (sd)
county |>
  summarize(sd = sd(unemployment_rate, na.rm = TRUE))

# combine
county |>
  summarize(mean = mean(unemployment_rate, na.rm = TRUE),
            median = median(unemployment_rate, na.rm = TRUE),
            min = min(unemployment_rate, na.rm = TRUE),
            max = max(unemployment_rate, na.rm = TRUE),
            sd = sd(unemployment_rate, na.rm = TRUE)) |>
  mutate(range = max - min,
         lower = mean - sd,
         upper = mean + sd)

# box plot
county |>
  ggplot(aes(x = unemployment_rate)) +
  geom_boxplot()



